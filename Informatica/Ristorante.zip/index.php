<?php
    $piatti = array(
        'antipasti' => array(),
        'primi' => array()
    );
?>

<!DOCTYPE html>
<html lang="it">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Osteria del Borgo</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <form action="" method="post">
            <div class="menu">
                <button class="btn_menu" onclick="openSez('antipasti')">Antipasti</button>
                <button class="btn_menu" onclick="openSez('formaggi')">Formaggi</button>
                <button class="btn_menu" onclick="openSez('primi')">Primi</button>
                <button class="btn_menu" onclick="openSez('secondi')">Secondi</button>
                <button class="btn_menu" onclick="openSez('contorni')">Contorni</button>
                <button class="btn_menu" onclick="openSez('dessert')">Dessert</button>
                <button class="btn_menu" onclick="openSez('frutta')">Frutta</button>
                <button class="btn_menu" onclick="openSez('cafeAmari')">Cafè & Amari</button>
            </div>
            <div class="main">
                <header>
                    <h1>Osteria del Borgo</h1>
                    <p>Un'esperienza sensoriale unica</p>
                </header>
                <div class="sez" id="antipasti"></div>
                <div class="sez" id="formaggi"></div>
                <div class="sez" id="primi"></div>
                <div class="sez" id="secondi"></div>
                <div class="sez" id="contorni"></div>
                <div class="sez" id="dessert"></div>
                <div class="sez" id="frutta"></div>
                <div class="sez" id="cafeAmari"></div>
            </div>
        </form>
    </body>
</html>