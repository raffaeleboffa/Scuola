document.getElementById("antipasti").style.display = "flex";

function openSez(sezione) {
    document.getElementsByClassName("sez").style.display = "none";
    document.getElementById(sezione).style.display = "flex";
}